var Airtable = require("airtable");
Airtable.configure({
  endpointUrl: "https://api.airtable.com",
  apiKey: "keyrvBPB6UQnw66Mq",
});

var base = Airtable.base("appvSD68A4r3889NX");

storeDonor = (e) => {
  e.preventDefault();
  let donorData = document.forms["donorForm"];

  let data = {
    "First Name": donorData["Name"].value,
    "Last Name": donorData["name"].value,
    Gender: donorData["gender"].value,
    Place: donorData["place"].value,
    Email: donorData["email id"].value,
    "Phone Number": donorData["Ph no"].value,
    "Blood Group": donorData["bloodGroup"].value,
  };
  console.log(data);
  base("Donor Details").create(
    [
      {
        fields: data,
      },
    ],
    function (err, records) {
      if (err) {
        console.error(err);
        return;
      }
    }
  );
};
