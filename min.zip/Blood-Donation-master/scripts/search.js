var Airtable = require("airtable");
Airtable.configure({
  endpointUrl: "https://api.airtable.com",
  apiKey: "keyrvBPB6UQnw66Mq",
});

var base = Airtable.base("appvSD68A4r3889NX");

function tableEmpty() {
  let div = document.createElement("div");
  div.innerHTML = "No Donors";
  div.style.marginTop = "20px";
  div.style.fontSize = "30px";
  div.style.fontWeight = "400";

  div.setAttribute("id", "no-requests");

  let container = document.getElementsByClassName("table-container")[0];
  container.style.textAlign = "center";
  container.appendChild(div);
}

function insertRow(id, record) {
  let x = document.getElementById("details");
  let len = x.rows.length;

  let new_row = document.createElement("tr");
  new_row.appendChild(document.createElement("th"));
  new_row.appendChild(document.createElement("td"));
  new_row.appendChild(document.createElement("td"));
  new_row.appendChild(document.createElement("td"));
  new_row.appendChild(document.createElement("td"));
  new_row.appendChild(document.createElement("td"));
  new_row.appendChild(document.createElement("td"));

  new_row.cells[0].innerHTML = len;
  new_row.cells[1].innerHTML = record["First Name"];
  new_row.cells[2].innerHTML = record["Last Name"];
  new_row.cells[3].innerHTML = record["Gender"];
  new_row.cells[4].innerHTML = record["Place"];
  new_row.cells[5].innerHTML = record["Email"];
  new_row.cells[6].innerHTML = record["Phone Number"];

  let tableBody = document.getElementById("blood-groups-body");

  tableBody.appendChild(new_row);
}

function loadTable(bloodGroup) {
  base("Donor Details")
    .select({
      view: "Grid view",
    })
    .eachPage(
      function page(records, fetchNextPage) {
        records = records.filter(
          (record) => record.fields["Blood Group"] == bloodGroup
        );
        if (records.length === 0) {
          tableEmpty();
        }

        records.forEach(function (record) {
          insertRow(record.id, record.fields);
        });

        fetchNextPage();
      },
      function done(err) {
        if (err) {
          console.error(err);
          return;
        }
      }
    );
}

window.onload = function () {
  let bloodGroup = document.getElementById("bloodGroup");

  bloodGroup.addEventListener("change", function () {
    let bloodGroupsBody = document.getElementById("blood-groups-body");
    bloodGroupsBody.remove();

    let new_body = document.createElement("tbody");
    new_body.setAttribute("id", "blood-groups-body");

    let table = document.getElementById("details");
    table.appendChild(new_body);

    let noRequests = document.getElementById("no-requests");
    if (noRequests) noRequests.remove();

    loadTable(bloodGroup.value);
  });
};
